package com.yourname.invisibleplayer.mixins;

import com.yourname.invisibleplayer.InvisiblePlayerDetector;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1297.class)
public class PlayerEntityMixin {
    
    @Inject(method = "isInvisible", at = @At("HEAD"), cancellable = true)
    private void onIsInvisible(CallbackInfoReturnable<Boolean> cir) {
        class_1297 entity = (class_1297) (Object) this;
        
        // Проверяем только для живых существ с эффектом невидимости
        if (entity instanceof class_1309 livingEntity) {
            // Если мод включен и существо имеет эффект невидимости
            if (InvisiblePlayerDetector.enabled && 
                livingEntity.method_6059(class_1294.field_5905)) {
                // Возвращаем false, чтобы существо было видно
                cir.setReturnValue(false);
            }
        }
    }
}
