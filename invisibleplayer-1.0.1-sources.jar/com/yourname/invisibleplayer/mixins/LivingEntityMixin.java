package com.yourname.invisibleplayer.mixins;

// Этот миксин больше не нужен, так как PlayerEntityMixin теперь работает для всех Entity
// Оставляем файл пустым или удаляем из mixins.json
