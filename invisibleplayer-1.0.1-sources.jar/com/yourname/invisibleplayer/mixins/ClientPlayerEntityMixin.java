package com.yourname.invisibleplayer.mixins;

import com.yourname.invisibleplayer.InvisiblePlayerDetector;
import net.minecraft.class_1294;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_746.class)
public class ClientPlayerEntityMixin {
    
    @Inject(method = "isInvisible", at = @At("HEAD"), cancellable = true)
    private void onIsInvisible(CallbackInfoReturnable<Boolean> cir) {
        class_746 player = (class_746) (Object) this;
        
        // Если мод включен и игрок имеет эффект невидимости
        if (InvisiblePlayerDetector.enabled && 
            player.method_6059(class_1294.field_5905)) {
            // Возвращаем false, чтобы игрок был виден
            cir.setReturnValue(false);
        }
    }
}
