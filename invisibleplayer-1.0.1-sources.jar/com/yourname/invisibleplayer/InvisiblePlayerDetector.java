package com.yourname.invisibleplayer;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_124;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Environment(EnvType.CLIENT)
public class InvisiblePlayerDetector implements ClientModInitializer {
    public static final String MOD_ID = "invisibleplayer";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    
    public static boolean enabled = true;
    public static boolean showOutline = true;
    public static int outlineColor = 0xFF0000; // Красный контур
    
    @Override
    public void onInitializeClient() {
        LOGGER.info("Invisible Entity Detector загружен!");
        
        // Регистрируем обработчик тиков
        ClientTickEvents.END_CLIENT_TICK.register(this::onClientTick);
        
        // Регистрируем кастомный рендерер
        registerCustomRenderers();
    }
    
    private void onClientTick(class_310 client) {
        if (client.field_1687 == null || client.field_1724 == null) return;
        
        // Проверяем всех игроков в радиусе
        for (class_1657 player : client.field_1687.method_18456()) {
            if (player == client.field_1724) continue; // Пропускаем себя
            
            // Проверяем, есть ли эффект невидимости
            if (player.method_6059(class_1294.field_5905)) {
                // Показываем уведомление (опционально)
                if (enabled && client.field_1724.method_5739(player) < 50) {
                    // Можно добавить визуальные эффекты
                    detectInvisibleEntity(player);
                }
            }
        }
        
        // Проверяем всех мобов в радиусе
        if (enabled) {
            client.field_1687.method_18112().forEach(entity -> {
                if (entity instanceof class_1309 livingEntity) {
                    // Пропускаем игроков (уже проверили выше)
                    if (livingEntity instanceof class_1657) return;
                    
                    // Проверяем, есть ли эффект невидимости
                    if (livingEntity.method_6059(class_1294.field_5905)) {
                        // Показываем мобов в радиусе 50 блоков
                        if (client.field_1724.method_5739(livingEntity) < 50) {
                            detectInvisibleEntity(livingEntity);
                        }
                    }
                }
            });
        }
    }
    
    private void detectInvisibleEntity(class_1309 entity) {
        // Логируем обнаружение
        if (class_310.method_1551().field_1724 != null) {
            String entityName = entity instanceof class_1657 
                ? ((class_1657) entity).method_5477().getString()
                : entity.method_5864().method_5882();
            
            String message = class_124.field_1061 + "[Невидимка обнаружен] " + 
                           class_124.field_1068 + entityName + 
                           class_124.field_1080 + " находится рядом!";
            // Можно отправить сообщение в чат
            // MinecraftClient.getInstance().player.sendMessage(
            //     Text.literal(message), false
            // );
        }
    }
    
    private void registerCustomRenderers() {
        // Регистрируем кастомный рендерер для невидимых игроков
        EntityRendererRegistry.register(
            net.minecraft.class_1299.field_6097,
            (context) -> new InvisiblePlayerRenderer(context)
        );
    }
}
