package com.yourname.invisibleplayer;

import net.minecraft.class_1294;
import net.minecraft.class_1657;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_583;
import net.minecraft.class_922;

public class InvisiblePlayerRenderer extends class_922<class_1657, class_583<class_1657>> {
    
    public InvisiblePlayerRenderer(class_5617.class_5618 context) {
        super(context, null, 0.5f);
    }
    
    @Override
    public class_2960 getTexture(class_1657 entity) {
        return new class_2960("minecraft", "textures/entity/player/wide/steve.png");
    }
    
    @Override
    public void render(class_1657 entity, float f, float g, class_4587 matrixStack,
                      class_4597 vertexConsumerProvider, int i) {
        
        // Если игрок невидим, но мод включен - показываем его
        if (entity.method_6059(class_1294.field_5905) && 
            InvisiblePlayerDetector.enabled) {
            
            // Отключаем эффект невидимости для рендеринга
            boolean wasInvisible = entity.method_5767();
            entity.method_5648(false);
            
            // Рендерим игрока
            super.method_4054(entity, f, g, matrixStack, vertexConsumerProvider, i);
            
            // Восстанавливаем состояние
            entity.method_5648(wasInvisible);
            
            // Добавляем контур, если включен
            if (InvisiblePlayerDetector.showOutline) {
                renderOutline(entity, matrixStack, vertexConsumerProvider);
            }
        } else {
            // Обычный рендеринг
            super.method_4054(entity, f, g, matrixStack, vertexConsumerProvider, i);
        }
    }
    
    private void renderOutline(class_1657 entity, class_4587 matrices,
                               class_4597 vertexConsumers) {
        // Рисуем красный контур вокруг невидимого игрока
        matrices.method_22903();
        
        // Настройки контура
        float lineWidth = 0.1f;
        int color = InvisiblePlayerDetector.outlineColor;
        
        // Здесь можно добавить код для рисования контура
        // Это требует более сложной реализации с использованием шейдеров
        
        matrices.method_22909();
    }
    
    @Override
    protected boolean hasLabel(class_1657 entity) {
        // Всегда показываем имя, даже для невидимых
        return InvisiblePlayerDetector.enabled || super.method_4055(entity);
    }
}
